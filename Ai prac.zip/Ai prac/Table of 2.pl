table_2(X, Y, Z) :-
    between(1, X, Y),
    Z is 2 * Y.
?- table_2(10, Y, Z), write(Y), write(' x 2 = '), write(Z), nl, fail.
