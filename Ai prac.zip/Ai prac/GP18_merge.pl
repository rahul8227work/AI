merge([],[],[]).
merge([],L,L).
merge(L,[],L).
merge([H1|T1],L2,[H1|R]):-merge(T1,L2,R).
