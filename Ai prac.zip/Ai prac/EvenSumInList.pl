sum_even(List, Sum) :-
    sum_even(List, 0, Sum).

sum_even([], Sum, Sum).
sum_even([X|Xs], Acc, Sum) :-
    (X mod 2 =:= 0 ->
        NewAcc is Acc + X,
        sum_even(Xs, NewAcc, Sum)
    ;
        sum_even(Xs, Acc, Sum)
    ).
?- sum_even([1, 2, 3, 4, 5, 6], Sum).
