add_lists([], [], []).
add_lists([X|Xs], [Y|Ys], [Z|Zs]) :-
    Z is X + Y,
    add_lists(Xs, Ys, Zs).
