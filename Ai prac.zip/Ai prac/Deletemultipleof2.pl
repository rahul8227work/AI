delete_multiples_of_two([], []).
delete_multiples_of_two([X|Xs], Ys) :-
    0 is X mod 2,
    delete_multiples_of_two(Xs, Ys).
delete_multiples_of_two([X|Xs], [X|Ys]) :-
    1 is X mod 2,
    delete_multiples_of_two(Xs, Ys).
