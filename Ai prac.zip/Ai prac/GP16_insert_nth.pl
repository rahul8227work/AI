insert_nth(1,N,[],[N]):-!.
insert_nth(_I,_N,[],[]):-!.
insert_nth(1,N,L,[N|T]):-insert_nth(0,N,L,T).
insert_nth(I,N,[H|T1],[H|T2]):-X is I-1,insert_nth(X,N,T1,T2).
